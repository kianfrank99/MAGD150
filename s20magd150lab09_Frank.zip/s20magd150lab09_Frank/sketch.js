
let capture;
let mic;


function setup() {

 let cnv = createCanvas(400, 400);
background(50);

 
  
  cnv.mousePressed(userStartAudio); //audio will play on mousepress
  textAlign(CENTER);
  mic = new p5.AudioIn();
  mic.start();
  
  capture = createCapture(VIDEO); //captures the user's webcam footage and displays it to them
  capture.size(200, 200);
  capture.hide();

 
  
 }



function draw() {

  fill(255);
  text('start', width/2, 20); //users presses start to here audioln capture
  
  micLevel = mic.getLevel();
  let y = height - micLevel * height;
  ellipse(width/2, y, 10, 10);


image(capture, 120, 120, 150, 200); //places the capture in the center of the screen.


   
}










