
function setup() {
  createCanvas(400, 400);
  
  
}

function draw() {
 background(50);
 
 stroke(255, 204, 0);
 strokeWeight(15);
 fill(255, 230, 0);
 circle(200, 200, 300);
  
 noStroke();
 fill(255, 60, 47);
 circle(140, 140, 50);
 circle(180, 100, 50);
 circle(240, 100, 50);
 circle(250, 200, 50);
 circle(190, 160, 50);
 circle(170, 300, 50);
 circle(145, 250, 50);
 circle(240, 270, 50);
 circle(290, 240, 50);
 circle(110, 200, 50);  
 circle(290, 150, 50);
 
  if (keyIsPressed) {
    fill(255);   
    textSize(100);
    text(key, width / 2.0, height / 4.0);
  
  }
  function keyPressed() {
  print(key + " " + keyCode + " pressed.");
  textSize(160);
  fill(255, 0, 0);
  text(key, width / 3.0, height / 3.0);
  }
  //:wanted to make the letters stay on screen so that user could type out pizza, but couldnt figure it out     
  
  

}

