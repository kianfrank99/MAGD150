


scroll = [
  "NOW IN THEATERS"]; //calling scroll in the draw will display this text

var f; //font variable
var x;
var index=0;
var img1;
var img2;
var lines;
var y;


function setup() {
  createCanvas(500, 700,);

  img1 = loadImage("dog.jpg");
  img2 = loadImage("animal4.jpg");
 
  f = loadFont("arial.ttf");
  x = width;
  y = width;
  
  lines = loadStrings("info.txt")



}


function draw() {
  background(50);
  
  img1.filter(GRAY); //making the filter only apply to img1.
  img2.filter(INVERT); //making filter only apply to img2.

  image(img1, 250, 250);
  image(img2, 50, 250) 

  textFont(f);
  textSize(32);
  textAlign(CENTER, CENTER);
  text('THE DOGS', 250, 100);
  
  fill(255);
  
  text(scroll[index], x, height-100); //where the text will scroll on screen.
  
  x = x - 1;
  y = y - 0;
  
  textSize(20);
  text(lines[index], y -250 , height-50); //text being called from .txt file.
  
  
}


