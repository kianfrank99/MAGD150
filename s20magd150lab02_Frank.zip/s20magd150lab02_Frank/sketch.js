function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(30);
  
  colorMode(RGB, 230);
  
  
  fill(230);
  circle(10, 5, 5);
  circle(110, 10, 5);
  circle(300, 10, 5);
  circle(200, 70, 5);
  circle(145, 267, 5);
  circle(222, 340, 5);
  circle(300, 276, 5);
  circle(380, 185, 5);
  circle(15, 299, 5);
  circle(110, 375, 5);
  circle(380, 380, 5);
  circle(250, 180, 5);
  

  noStroke();
  fill(200);
  arc(50, 50, 80, 80, 0, PI + QUARTER_PI, CHORD);
  
  
  fill(255, 124, 47);
  stroke(255, 204, 0);
  strokeWeight(10);
  circle(100, 200, 100);
  
  
  noFill();
  stroke(255, 230, 225);
  bezier(180, 200, 10, 180, 200, 250, 30, 205);
 
  
 colorMode(HSB, 230); 
 fill(204, 94, 255);
 noStroke();
 triangle(280, 100, 250, 100, 265, 50);
 triangle(315, 105, 265, 120, 265, 80);
 triangle(215, 105, 265, 120, 265, 80);
 triangle(265, 150, 250, 105, 280, 105);
 
 colorMode(RGB, 230);  
 fill(100, 46, 232);
 noStroke(); 
 quad(350, 300, 320, 367, 330, 315, 360, 270); 
   
}