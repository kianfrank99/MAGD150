var x = 100;
var y = 385;
var w = 90;
var h = 40;

var cx = 400;
var cy = 385;
var cw = 75;
var ch = 50;

function setup() {
  createCanvas(500, 500);
  background(150);
  
  rectMode(CENTER);
  noStroke();
  fill(70);
  rect(250,250,450,350);
  
  rectMode(CENTER);
  noStroke();
  fill(35);
  rect(250,225,400,250);
  
 
  }

function draw() {
    
 ellipseMode(CENTER);
  fill(255,53,26);
  ellipse(cx,cy,cw,ch);
  
  
  fill(255);
  textSize(20);
  text('SAD', 381, 390);
  
  rectMode(CENTER);
  
  fill(255,145,23);
  rect(x,y,w,h);
  
  fill(255);
  textSize(20);
  text('HAPPY',68,391);
  
     if(mouseIsPressed){
  if(mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h){
     ellipseMode(CENTER);
    fill(255,231,40);
    noStroke();
    ellipse(250,225,100,100);  
    fill(0);
    ellipse(230,215,10,10);
    ellipse(270,215,10,10);
    stroke(0);
    curve(250, 20, 270, 235, 230, 235, 250, 20);
  
   }
     }
       
       if(mouseIsPressed){
  if(mouseX>cx && mouseX <cx+cw && mouseY>cy && mouseY <cy+ch){
     ellipseMode(CENTER);
    fill(255,231,40);
    noStroke();
    ellipse(250,225,100,100);  
    fill(0);
    ellipse(230,215,10,10);
    ellipse(270,215,10,10);
    stroke(0);
    noFill();
    bezier(270, 250, 250, 200, 235, 230, 230, 250);
  }
} 
}